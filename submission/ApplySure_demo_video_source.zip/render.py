import asyncio, subprocess, time
from playwright.async_api import async_playwright
FPS=30; DUR=66.0; N=int(FPS*DUR)
async def main():
    ff=subprocess.Popen(["ffmpeg","-y","-hide_banner","-loglevel","error","-f","image2pipe","-framerate",str(FPS),"-c:v","mjpeg","-i","-",
        "-i","/tmp/claude-0/vid/soundtrack.wav","-c:v","libx264","-preset","slow","-crf","20","-pix_fmt","yuv420p","-profile:v","high",
        "-c:a","aac","-b:a","192k","-movflags","+faststart","-shortest","/tmp/claude-0/vid/ApplySure_demo.mp4"],stdin=subprocess.PIPE)
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={"width":1920,"height":1080})
        await pg.goto("file:///tmp/claude-0/vid/index.html"); await pg.evaluate("window.ready"); await pg.wait_for_timeout(500)
        t0=time.time()
        for i in range(N):
            await pg.evaluate(f"render({i/FPS})")
            ff.stdin.write(await pg.screenshot(type="jpeg", quality=92))
            if i%300==0: print(i, round(time.time()-t0,1), flush=True)
        await b.close()
    ff.stdin.close(); ff.wait(); print("ffmpeg exit", ff.returncode)
asyncio.run(main())
