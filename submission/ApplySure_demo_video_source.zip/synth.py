# Original soundtrack for the ApplySure demo. Every sound is generated here from sine waves and noise.
import numpy as np, wave
from scipy.signal import butter, sosfilt
SR=48000; DUR=66.0; N=int(SR*DUR); rng=np.random.default_rng(7)
mix=np.zeros((N,2))
def T(n): return np.arange(n)/SR
def place(sig, t0, gain=1.0, pan=0.0):
    i=int(t0*SR); sig=np.asarray(sig)
    if sig.ndim==1: sig=np.stack([sig*(1-max(pan,0)), sig*(1+min(pan,0))],1)
    j=min(N,i+len(sig)); mix[i:j]+=sig[:j-i]*gain
def lp(x,f,o=2): return sosfilt(butter(o,f,'low',fs=SR,output='sos'),x)
def hp(x,f,o=2): return sosfilt(butter(o,f,'high',fs=SR,output='sos'),x)
def bp(x,lo,hi,o=2): return sosfilt(butter(o,[lo,hi],'band',fs=SR,output='sos'),x)
def env(n,a,r): t=T(n); return np.minimum(1,t/max(a,1e-4))*np.exp(-t/max(r,1e-4))
def note(f): return 440*2**((f-69)/12)

def boom(dur=1.8,f0=110,f1=34,g=1.0):
    n=int(SR*dur); t=T(n); f=f1+(f0-f1)*np.exp(-t*7); ph=2*np.pi*np.cumsum(f)/SR
    body=np.sin(ph)*np.exp(-t*2.2); click=lp(rng.standard_normal(n),3000)*np.exp(-t*60)*0.6
    tail=lp(rng.standard_normal(n),400)*np.exp(-t*3)*0.25
    return (body+click+tail)*g
def whoosh(dur=0.9):
    n=int(SR*dur); t=T(n); x=rng.standard_normal(n); out=np.zeros(n)
    # sweep a band-pass upward by crossfading 6 bands
    bands=[(300,700),(600,1400),(1200,2600),(2200,4500),(4000,7500),(6500,11000)]
    for k,(lo,hi) in enumerate(bands):
        c=(k+0.5)/len(bands); w=np.exp(-((t/dur-c)**2)/0.02); out+=bp(x,lo,hi)*w
    shape=np.sin(np.pi*np.clip(t/dur,0,1))**2
    l=out*shape; r=np.roll(l,int(0.004*SR))
    return np.stack([l,r],1)*0.5
def bell(f,dur=2.2,g=0.3):
    n=int(SR*dur); t=T(n)
    s=sum(a*np.sin(2*np.pi*f*m*t)*np.exp(-t*d) for m,a,d in [(1,1,2.2),(2.0,.5,3.5),(3.01,.25,5),(4.2,.12,7)])
    return s*np.minimum(1,t/0.004)*g
def tick(g=0.35):
    n=int(SR*0.06); return hp(rng.standard_normal(n),2500)*env(n,0.0005,0.008)*g
def tap(g=0.5):
    n=int(SR*0.12); t=T(n); s=np.sin(2*np.pi*1800*t)*np.exp(-t*90)+hp(rng.standard_normal(n),3000)*np.exp(-t*200)*0.4
    return s*g
def kick(g=0.9):
    n=int(SR*0.45); t=T(n); f=45+90*np.exp(-t*35); return np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*7)*g
def hat(g=0.18):
    n=int(SR*0.09); return hp(rng.standard_normal(n),7000)*env(n,0.001,0.02)*g
def pad(freqs, dur, g=0.12):
    n=int(SR*dur); t=T(n); x=np.zeros(n)
    for f in freqs:
        for det in (-0.12,0.0,0.12):
            ph=np.cumsum(np.full(n,f*2**(det/12)))/SR
            x+=2*(ph%1)-1       # saw
    x=lp(x/len(freqs)/3,1400,2)
    a=np.minimum(1,t/0.9)*np.minimum(1,(dur-t)/0.9)
    return x*a*g
def pluck(f,g=0.12):
    n=int(SR*0.7); t=T(n)
    return (np.sin(2*np.pi*f*t)+0.3*np.sin(2*np.pi*2*f*t))*np.exp(-t*6)*np.minimum(1,t/0.003)*g

# --- Hook (0 - 7.4 s): tension drone, impacts, ticks
n=int(SR*7.6); t=T(n)
drone=(np.sin(2*np.pi*55*t)+0.5*np.sin(2*np.pi*82.4*t)+0.25*np.sin(2*np.pi*110*t*1.003))
drone*=np.minimum(1,t/1.5)*np.minimum(1,(7.6-t)/0.4)*(0.5+0.5*t/7.6)*0.18
place(drone,0.0)
place(boom(2.2,130,32,1.0),0.02)
place(tick(),0.90,pan=-0.3); place(tick(),1.55,pan=0.3); place(tick(0.25),1.90)
place(whoosh(0.8),3.0)
place(boom(1.4,150,40,0.7),5.30)
place(whoosh(1.0),6.55)

# --- Logo (7.4 s): bright bell arpeggio
for k,m in enumerate([72,76,79,84]):
    place(bell(note(m),2.4,0.22),7.62+k*0.11,pan=(k-1.5)*0.25)

# --- Music bed 7.4 - 66 s, 100 BPM
beat=0.6; bar=4*beat
chords=[[48,55,59,62,64],[45,52,55,59,64],[41,48,52,57,60],[43,50,55,59,62]]   # Cmaj9  Am(add9)  Fmaj7  G
start=7.4; t0=start; ci=0
while t0<64.6:
    ch=chords[ci%4]; dur=2*bar
    duck = 0.45 if 49.0<=t0<56.0 else 1.0
    place(pad([note(m) for m in ch],dur+0.6,0.11*duck),t0)
    place(pluck(note(ch[0]-12),0.10*duck),t0)
    # arpeggio in 8ths from 10.6 s
    if t0>=10.0 and not (49.0<=t0<56.0):
        seq=[ch[1]+12,ch[2]+12,ch[3]+12,ch[4]+12,ch[3]+12,ch[2]+12,ch[1]+12,ch[2]+12]
        for k in range(16):
            tt=t0+k*beat/2
            if tt<64.0: place(pluck(note(seq[k%8]),0.055),tt,pan=0.3 if k%2 else -0.3)
    t0+=dur; ci+=1
# rhythm from 10.6 s, paused for the privacy scene
tb=10.6
while tb<64.0:
    inpriv=49.0<=tb<56.0
    if not inpriv:
        place(kick(0.55),tb)
        if tb>=20.0:
            place(hat(),tb+beat/2,pan=0.2)
    tb+=beat
# transitions, taps and accents synced to the picture
for tw in [10.25,19.65,27.65,37.65,48.6,55.65]: place(whoosh(0.9),tw)
for tt in [19.5,27.4,32.4,37.5]: place(tap(0.45),tt)
for ts in [24.0,33.0,44.5]: place(tap(0.25),ts)
place(bell(note(84),1.6,0.16),40.0); place(bell(note(88),1.8,0.16),40.14)     # chips appear
place(bell(note(76),2.0,0.12),49.4,pan=-0.2)                                    # privacy
place(boom(2.0,120,36,0.75),56.2)                                               # end card
for k,m in enumerate([60,67,72,76,79]): place(bell(note(m),3.0,0.12),56.25+k*0.06,pan=(k-2)*0.2)
place(pad([note(m) for m in [48,55,60,64,67]],9.0,0.13),56.2)

# master: gentle fade, soft clip, normalise to -1 dBFS
tt=T(N); fade=np.minimum(1,(DUR-tt)/2.5)[:,None]; mix*=fade
mix=np.tanh(mix*1.2); mix/=np.max(np.abs(mix))/10**(-1/20)
with wave.open('/tmp/claude-0/vid/soundtrack.wav','wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix*32767).astype('<i2').tobytes())
print("ok", mix.shape[0]/SR, "s")
